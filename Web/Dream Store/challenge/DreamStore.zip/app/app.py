from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
import mysql.connector, json
from datetime import timedelta 
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from base64 import b64decode
import re

app = Flask(__name__)
app.secret_key = 'twitter/x@Melotover'
app.permanent_session_lifetime = timedelta(minutes=45)

def connect():
    global db_connection
    db_connection = mysql.connector.connect(
        host='db',
        user='root',
        password='root',
        database='dreamstore',
        port='3306'
    )

with open('private.pem', 'rb') as f:
    private_key = f.read()
    key = RSA.importKey(private_key)
    cipher = PKCS1_OAEP.new(key, hashAlgo=SHA256)

def decrypt_middleware():
    connect()
    if request.method == 'POST' or request.method == 'PUT':
        try:
            json_data = request.get_json()
            encrypted_data = json_data.get('data')
            if encrypted_data is not None:
                key = RSA.import_key(private_key)
                cipher = PKCS1_OAEP.new(key, hashAlgo=SHA256)
                decrypted_data = cipher.decrypt(b64decode(encrypted_data)).decode('utf-8')
                request.data_decrypted = json.loads(decrypted_data)
            else:
                return jsonify(error="Error handling the request."), 400
        except Exception as e:
            return jsonify(error="Error handling the request."), 400
        pass

app.before_request(decrypt_middleware)

@app.after_request
def add_security_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Credintials'] = 'true'
    return response

def escape(string):
    escaped = re.sub(r'(?i)join|([' + re.escape(r'"\',\\%^&$*#') + r'])', r'\\\1', string)
    return escaped
    
@app.route('/')
def index():
    if 'loggedin' in session:
        return redirect(url_for('profile'))
    else:
        return render_template('index.html') 
        
@app.route('/login', methods=['POST'])
def login():
    if 'loggedin' in session:
        return redirect(url_for('profile'))
    else:
        data = request.data_decrypted
        username, password= data.get('username'), data.get('password')
        if username and password:
            username, password = escape(username.strip()), escape(password)
            query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}';"
            try:
                db_cursor = db_connection.cursor()
                db_cursor.execute(query)
                user = db_cursor.fetchone()
                db_cursor.close()
                if user:
                    session['username'] = username
                    session['loggedin'] = True
                    return jsonify(message="Login successful.")
                else:
                    return jsonify(error="Invalid credentials."), 401
            except mysql.connector.Error as e:
                return jsonify(error="Error handling the request."), 401
        return jsonify(error="Missing username or password"), 400


@app.route('/register', methods=['POST'])
def register():
    if 'loggedin' in session:
        return redirect(url_for('profile'))
    else:
        data = request.data_decrypted
        username, email, password= data.get('username'), data.get('email'), data.get('password')
        if username and email and password:
            username, email, password = escape(username.strip()), escape(email.strip()), escape(password)
            query = f"SELECT * FROM users WHERE username = '{username}' OR email = '{email}';"
            try:
                db_cursor = db_connection.cursor()
                db_cursor.execute(query)
                user_exist = db_cursor.fetchone()
                if user_exist:
                    return jsonify(message="User already exist.")
                query = f"INSERT INTO users (username, email, password) VALUES ('{username}', '{email}', '{password}');"
                db_cursor.execute(query)
                db_connection.commit()
                return jsonify(message="Registration successful, you can login now.")
            
            except mysql.connector.Error as e:
                return jsonify(error="Error handling the request."), 401
            
        return jsonify(error="Missing information"), 400

@app.route('/profile')
def profile():
    if 'loggedin' in session:
        return render_template('profile.html', username=session['username'])
    else:
        return redirect(url_for('index'))

@app.route('/store', methods=['GET'])
def store_get():
    if 'loggedin' in session:
        return render_template('store.html')
    else:
        return redirect(url_for('index'))

@app.route('/store', methods=['POST'])
def store():
    if 'loggedin' in session:
        data = request.data_decrypted
        country, product_hash= data.get('shipsTo'), data.get('hash')
        if product_hash and country:
            country = escape(country.strip())
            product_hash = escape(product_hash.strip())[:32]
            query = f"SELECT * FROM products WHERE product_hash = '{product_hash}' AND ships_to LIKE '%{country}%';"
            try:
                db_cursor = db_connection.cursor()
                db_cursor.execute(query)
                products = db_cursor.fetchall()
                db_cursor.close()
                if products:
                    return render_template('stock.html', products=products,message="")
                else:
                    return render_template('stock.html', products=products,message="No products found.")
            except mysql.connector.Error as e:
                return render_template('stock.html', products=[],message="Error handling the request.")
        else:
            return render_template('stock.html', products=[],message="Missing parameters.")

    else:
        return redirect(url_for('index'))

@app.route('/buy', methods=['POST','GET'])
def buy(): 
    if 'loggedin' in session:
        return jsonify(error="We are working on it."), 400
    else:
        return jsonify(error="You are not authenticated."), 400 
        
@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0")

