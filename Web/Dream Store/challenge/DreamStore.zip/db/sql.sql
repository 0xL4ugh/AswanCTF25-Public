CREATE DATABASE dreamstore;
use dreamstore;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL
);

INSERT INTO users (username, email, password) VALUES ('admin', 'admin@localhost.com', 'IamTheAutherAndTheyCallMeMelotover');
INSERT INTO users (username, email, password) VALUES ('test', 'test@localhost.com', 'testover');

CREATE TABLE IF NOT EXISTS products (
    product_name VARCHAR(255) NOT NULL,
    price VARCHAR(255) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    product_hash VARCHAR(32) NOT NULL,
    ships_to VARCHAR(255) NOT NULL
);


INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('Laptop G6 788', '1050', 'https://www.notebookcheck.net/uploads/tx_nbc2/hpG6_black__06.jpg', '49f5c841b83b21a12ed2ffa1c3b813cf','USA,Canada,UAE,Palestine,Germany,Egypt');
INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('RTX 4090', '900', 'https://www.trustedreviews.com/wp-content/uploads/sites/54/2022/10/Nvidia-GeForce-RTX-4090-7-scaled.jpg', '29dfbc72f1c3830c976103b15a39d909','USA,Canada,UAE,Palestine,Germany,Egypt');
INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('Keyboard GALAX CL-300', '32', 'https://m.media-amazon.com/images/I/41I+dCpi4jL._AC_UF894,1000_QL80_.jpg', 'd4daaf309f1951022e4554ddf10cffd5','USA,Canada,UAE,Palestine,Germany,Egypt');
INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('Mouse RedDragon M100', '49', 'https://m.media-amazon.com/images/I/51Fw-aGClBS._AC_UF350,350_QL50_.jpg', '90efad19e17ca5eec5a11fe4a60837ab','USA,Canada,UAE,Palestine,Germany,Egypt');
INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('Intel i5 13400f', '230', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZibTWKaLohZsYTEiAdE_2rrOVvCxkEhT6aA&usqp=CAU', 'e8d67004c48d2c3c683f6e369d00dc92','USA,Canada,UAE,Palestine,Germany,Egypt');


CREATE TABLE IF NOT EXISTS flag (
    flag VARCHAR(100) NOT NULL
);

INSERT INTO flag (flag) VALUES ('YAO{Is_It_Worth_CuTing_After_EscAPING?}');

