CREATE DATABASE dreamstore;
use dreamstore;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL
);

INSERT INTO users (username, email, password) VALUES ('admin', 'admin@localhost.com', 'DummyData_IamTheAutherAndTheyCallMeMelotover');
INSERT INTO users (username, email, password) VALUES ('test', 'test@localhost.com', 'testover');

CREATE TABLE IF NOT EXISTS products (
    product_name VARCHAR(255) NOT NULL,
    price VARCHAR(100) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    product_hash VARCHAR(32) NOT NULL,
    ships_to VARCHAR(255) NOT NULL
);


INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('product_name1', 'price1', 'product_image_url1', 'product_hash1', 'countries_for_shipping1');
INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('product_name2', 'price2', 'product_image_url2', 'product_hash2', 'countries_for_shipping2');
INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('product_name3', 'price3', 'product_image_url3', 'product_hash3', 'countries_for_shipping3');
INSERT INTO products (product_name, price, image_url, product_hash, ships_to) VALUES ('product_name4', 'price4', 'product_image_url4', 'product_hash4', 'countries_for_shipping4');

CREATE TABLE IF NOT EXISTS flag ( flag VARCHAR(100) NOT NULL );
INSERT INTO flag (flag) VALUES ('YAO{REDACTED}');

