import time
import subprocess

# Sleep for 10 seconds
time.sleep(10)

# Run the app.py script using subprocess
subprocess.run(["python", "app.py"])
